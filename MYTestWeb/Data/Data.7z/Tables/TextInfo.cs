﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MYORM.Attributes;

namespace Data.Tables
{
    public class TextInfo : MYORM.MYItemBase
    {
        [PrimaryKey]
        [Identity(1, 1)]
        [ValueNotNull]
        public int iId
        {
            get;
            set;
        }

        [ValueNotNull]
        public int mId
        {
            get;
            set;
        }

        [DBValueType("text")]
        public string content
        {
            get;
            set;
        }
    }
}
