﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MYORM.Attributes;

namespace Data.Tables
{
    public class DateInfo : MYORM.MYItemBase
    {
        [PrimaryKey]
        [Identity(1, 1)]
        [ValueNotNull]
        public int iId
        {
            get;
            set;
        }

        [ValueNotNull]
        public int mId
        {
            get;
            set;
        }

        public DateTime content
        {
            get;
            set;
        }
    }
}
