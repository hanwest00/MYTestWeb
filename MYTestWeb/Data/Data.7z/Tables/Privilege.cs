﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MYORM.Attributes;

namespace Data.Tables
{
    public class Privilege : MYORM.MYItemBase
    {
        public int uId
        {
            get;
            set;
        }

        public int cId
        {
            get;
            set;
        }
    }
}
