﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MYORM.Attributes;

namespace Data.Tables
{
    public class FileInfo : MYORM.MYItemBase
    {
        [PrimaryKey]
        [Identity(1, 1)]
        [ValueNotNull]
        public int iId
        {
            get;
            set;
        }

        [ValueNotNull]
        public int mId
        {
            get;
            set;
        }

        [DBValueType("nvarchar(127)")]
        public string url
        {
            get;
            set;
        }

        [DBValueType("nvarchar(127)")]
        public string fileName
        {
            get;
            set;
        }
    }
}
